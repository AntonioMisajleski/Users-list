
const api_url = "https://dummyapi.io/data/v1/user";
async function getapi(url) {

  const response = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      'app-id': '6175761be177fa49d5989890'
    },
  });
  var data = await response.json();
  console.log(data);

  show(data);
}

getapi(api_url);

function show(data) {
  let tab =
    `<tr class ="bg-color">
    
		<th>Picture</th>
		<th>Title</th>
		<th>First name</th>
		<th>Last name</th>
    <th>Action</th>
		</tr>`;


  for (let r of data.data) {
    tab += `<tr>
    <td> <img src = "${r.picture}" class="profile-image"></td>	
    <td >${r.title} </td>
    <td>${r.firstName}</td>
    <td>${r.lastName}</td>
    
    <td > <button class="btn btn-secondary"  onclick="passId('${r.id}')">More info</button></td>	
    </tr>`;

  }

  document.getElementById("users").innerHTML = tab;


}

function passId(id) {

  location = "detailInfo.html?id=" + id;

}





