const inputFirstName = document.getElementById("firstName");
const inputLastName = document.getElementById("lastName");
const inputEmail = document.getElementById("email");
const inputPhone = document.getElementById("phone");
const inputPicture = document.getElementById("pic");
const inputState = document.getElementById("state");
const inputStreet = document.getElementById("street");
const inputCity = document.getElementById("city");
const buttonSendUser = document.getElementById("sendUser");



buttonSendUser.onclick = function addUser() {

  let firstName = inputFirstName.value;
  let lastName = inputLastName.value;
  let email = inputEmail.value;
  let phone = inputPhone.value;
  let picture = inputPicture.value;
  let street = inputStreet.value;
  let state = inputState.value;
  let city = inputCity.value;

  const sendUser = {
    firstName: firstName,
    lastName: lastName,
    email: email,
    phone: phone,
    state: state,
    street: street,
    city: city,
    picture: picture

  };
  const api_url_user_create = "https://dummyapi.io/data/v1/user/create";
  fetch(api_url_user_create, {

    headers: {
      'Content-Type': 'application/json',
      'app-id': '6175761be177fa49d5989890',
    },
    method: 'POST',
    body: JSON.stringify(sendUser),

  })

    .then(response => {
      if (!response.ok) { throw response; }
      alert("Successfully created user ");
      location.reload();
    })

    .catch(err => {
      err.text().then(errorMessage => {

        alert(errorMessage);
        location.reload();
      });
    });


};

const redirect = document.getElementById("back");

redirect.onclick = function redir() {
  window.location.href = "index.html";
};