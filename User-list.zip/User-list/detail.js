const urlSearchParams = new URLSearchParams(location.search);
const params = Object.fromEntries(urlSearchParams);

const api_url_user =
  "https://dummyapi.io/data/v1/user/" + params.id;

fetch(api_url_user, {
  headers: {
    'Content-Type': 'application/json',
    'app-id': '6175761be177fa49d5989890'
  },
})
  .then(response => response.json())
  .then(user => show(user));

function show(data) {
  console.log(data);
  const godina = new Date(data.dateOfBirth);
  const rGodina = new Date(data.registerDate);
  const phone = data.phone;


  let tab =
    `
      <div class="card card1" style="width: 30rem;">
      <img src="${data.picture}" class="card-img-top" alt="profile-image">
      <div class="card-body">
        <h4 class="card-title"><strong>${data.title}: </strong>${data.firstName} ${data.lastName}</h4>
        <p class="card-text">Date of birth: ${godina.getDate()}/${godina.getMonth() + 1}/${godina.getFullYear()}</p>
        <p class="card-text">Gender: ${data.gender}</p>
        
      </div>
      <ul class="list-group list-group-flush">
        <li class="list-group-item">Phone: ${formatPhoneNumber(phone)}</li>
        <li class="list-group-item">Email: ${data.email}</li>
        <li class="list-group-item">Adrres: <br>
        Country: ${data.location.country}, <br>
        State: ${data.location.state},<br>
        City: ${data.location.city},<br>
        Street: ${data.location.street}
        </li>
      </ul>
      <div class="card-body card-btnn">
        <a href="index.html" class="btn btn-secondary btn-lg">Go Back</a>
        
      </div>
      <div class="card-footer text-muted">
        Registered ${rGodina.getDay()}/${rGodina.getMonth() + 1}/${rGodina.getFullYear()}
      </div>
    </div>
    `;


  document.getElementById("users").innerHTML = tab;


}

function formatPhoneNumber(phone) {
  let cleaned = ('' + phone).replace(/\D/g, '');
  let match = cleaned.match(/^(1|)?(\d{3})(\d{3})(\d{4})$/);
  if (match) {
    let intlCode = (match[1] ? '+1 ' : '');
    return [intlCode, '(', match[2], ') ', match[3], '-', match[4]].join('');
  }
  if (cleaned <= 8)
    return '(' + cleaned.slice(0, 2) + ')' + ' ' + cleaned.slice(2, 5) + '-' + cleaned.slice(5,);

  return '(' + cleaned.slice(0, 3) + ')' + ' ' + cleaned.slice(3, 6) + '-' + cleaned.slice(6,);
}

